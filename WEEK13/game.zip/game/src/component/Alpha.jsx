import React from 'react'
import {useState} from 'react'
import './Alpha.css'
export default function Alpha({btnName, enableButton, setbuttons, buttonObj}) {
    const [currentIndex, setCurrentIndex] = useState(0);
    const keys =  Object.keys(buttonObj)
   
    const nextKey = keys[keys.indexOf(btnName)+1]
    console.log(nextKey)
  const handleNextClick = () => {
    if (currentIndex < buttons.length-1) {
       
      setCurrentIndex(currentIndex + 1);

    } else if(currentIndex == buttons.length-1) {
      setCurrentIndex(0);
      
      enableButton(false);
     
     const updatedButton = {...buttonObj}
     updatedButton[`${nextKey}`] = true
     console.log(updatedButton)
     setbuttons(updatedButton)
      console.log(buttonObj)
     

    }
  };

  const buttons = ['Button 1', 'Button 2', 'Button 3', 'Button 4'];
  return (
    <div className='steps'>
        <h1>{btnName}</h1>
        {buttons.map((button, index) => (
        <button
          key={index}
          style={{ backgroundColor: index === currentIndex ? 'lightgreen' : '' }}
          onClick={() => alert(`Button ${index + 1} clicked`)}
        >
          {button}
        </button>
         ))}
         <button onClick={handleNextClick} disabled={btnName==='Alpha'?false:!buttonObj[btnName]}>Next</button>
        
    </div>
  )
}
