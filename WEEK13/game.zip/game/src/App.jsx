import { useState } from 'react'
import Alpha from './component/Alpha'

function App() {
  const [buttons, setButtons] = useState([]);
  const [buttonObj, setButtonObj] = useState({});
const [enableButton, setenableButton] = useState(false);
  const btns = ["Alpha", "Beta", "Gamma", "Theta"];
  const [index, setIndex] = useState(0);

  const addButtons = () => {
    setButtonObj({
    Alpha:true,
    Beta:false,
    Gamma:false,
    Theta:false
    })
   
    setenableButton(true)
    const newButton = btns[index];
    setButtons(prevButtons => [...prevButtons, newButton]);
    setIndex(prevIndex => prevIndex + 1);
  };

  return (
    <div className='container'>
      <button disabled={enableButton} className='add' onClick={addButtons}>+</button>
      {buttons.map((btn, idx) => (
        <Alpha btnName={btn} key={idx} enableButton={setenableButton} setbuttons={setButtonObj} buttonObj={buttonObj} />
      ))}
    </div>
  );
}

export default App;
