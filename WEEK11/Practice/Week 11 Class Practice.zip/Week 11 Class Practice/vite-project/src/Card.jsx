import React from 'react'

export function Card(){
    return (
        <div>
            <h1>Hello World</h1>
        </div>
    )
}

